#ifndef USER_H
#define USER_H

#include <iostream>
using namespace std;

class User
{
protected:
    int id;
    string name;
    string password;

public:
    User();
    User(int, string, string);
    User(const User&);
    User& operator=(const User&);

    void setId(int);
    void setName(string);
    void setPassword(string);

    int getId() const;
    string getName() const;
    string getPassword() const;

    virtual void display() = 0;
    virtual ~User();
};

#endif
