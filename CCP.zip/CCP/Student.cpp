#include "Student.h"

Student::Student() : User()
{
    department = "";
    transportApproved = false;
}

Student::Student(int i, string n, string p, string d, bool status)
    : User(i, n, p)
{
    department = d;
    transportApproved = status;
}

Student::Student(const Student& obj) : User(obj)
{
    department = obj.department;
    transportApproved = obj.transportApproved;
}

Student& Student::operator=(const Student& obj)
{
    if (this != &obj)
    {
        User::operator=(obj);
        department = obj.department;
        transportApproved = obj.transportApproved;
    }
    return *this;
}

void Student::setDepartment(string d) { department = d; }
void Student::setTransportStatus(bool s) { transportApproved = s; }
string Student::getDepartment() const { return department; }
bool Student::getTransportStatus() const { return transportApproved; }

void Student::applyTransport()
{
    cout << "\nTransport application submitted successfully.\n";
}

void Student::cancelRegistration()
{
    transportApproved = false;
    cout << "\nTransport registration cancelled.\n";
}

void Student::display()
{
    cout << "\n========== STUDENT DETAILS ==========\n";
    cout << "ID         : " << id << endl;
    cout << "Name       : " << name << endl;
    cout << "Department : " << department << endl;
    cout << "Transport  : " << (transportApproved ? "Approved" : "Not Approved") << endl;
}

Student::~Student() {}
