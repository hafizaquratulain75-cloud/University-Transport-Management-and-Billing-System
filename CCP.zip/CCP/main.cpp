#include <iostream>
#include "TransportManager.h"

using namespace std;

TransportManager tm;

void studentMenu(Student* s);
void adminMenu(Admin* a);

int main()
{
    int choice;

    do
    {
        cout <<"\n======================================\n";
        cout << "|   UNIVERSITY TRANSPORT SYSTEM        |\n";    
        cout << "======================================\n";
        cout << "1. Register as Student\n";
        cout << "2. Student Login\n";
        cout << "3. Admin Login\n";
        cout << "4. Exit\n";
        cout << "--------------------------------------\n";
        cout << "Enter choice: ";
        cin >> choice;

        // ---- REGISTER ----
        if (choice == 1)
        {
            int id;
            string name, pass, dept;

            cout << "\n--- STUDENT REGISTRATION ---\n";
            cout << "Enter Student ID   : "; cin >> id;

            if (tm.studentIdExists(id))
            {
                cout << "\nError: Student ID already exists!\n";
                continue;
            }

            cout << "Enter Name         : "; cin >> name;
            cout << "Enter Password     : "; cin >> pass;
            cout << "Enter Department   : "; cin >> dept;

            Student* s = new Student(id, name, pass, dept, false);
            tm.addStudent(s);
        }

        // ---- STUDENT LOGIN ----
        else if (choice == 2)
        {
            int id; string pass;

            cout << "\n--- STUDENT LOGIN ---\n";
            cout << "Enter Student ID : "; cin >> id;
            cout << "Enter Password   : "; cin >> pass;

            Student* s = tm.loginStudent(id, pass);

            if (s == nullptr)
            {
                cout << "\nLogin Failed! Invalid ID or Password.\n";
            }
            else
            {
                cout << "\nLogin Successful! Welcome, " << s->getName() << "!\n";
                studentMenu(s);
            }
        }

        // ---- ADMIN LOGIN ----
        else if (choice == 3)
        {
            int id; string pass;

            cout << "\n--- ADMIN LOGIN ---\n";
            cout << "Default: ID=1, Password=admin123\n";
            cout << "Enter Admin ID   : "; cin >> id;
            cout << "Enter Password   : "; cin >> pass;

            Admin* a = tm.loginAdmin(id, pass);

            if (a == nullptr)
            {
                cout << "\nLogin Failed! Invalid ID or Password.\n";
            }
            else
            {
                cout << "\nLogin Successful! Welcome, " << a->getName() << "!\n";
                adminMenu(a);
            }
        }

        else if (choice == 4)
        {
            tm.saveData();
            cout << "\nGoodbye!\n";
        }
        else
        {
            cout << "\nInvalid choice! Try again.\n";
        }

    } while (choice != 4);

    return 0;
}

// ======================== STUDENT MENU ========================

void studentMenu(Student* s)
{
    int choice;

    do
    {
        cout << "\n======================================\n";
        cout << "   STUDENT MENU - " << s->getName() << "\n";
        cout << "======================================\n";
        cout << "1. View My Profile\n";
        cout << "2. View All Routes\n";
        cout << "3. View All Vehicles\n";
        cout << "4. Apply for Transport\n";
        cout << "5. View My Transport Pass\n";
        cout << "6. Pay My Bill\n";
        cout << "7. Cancel Registration\n";
        cout << "8. Logout\n";
        cout << "--------------------------------------\n";
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 1)
        {
            s->display();
        }
        else if (choice == 2)
        {
            tm.displayAllRoutes();
        }
        else if (choice == 3)
        {
            tm.displayAllVehicles();
        }
        else if (choice == 4)
        {
            int rid, vid;
            double fee;

            cout << "\n--- APPLY FOR TRANSPORT ---\n";
            tm.displayAllRoutes();
            cout << "Enter Route ID   : "; cin >> rid;

            tm.displayAllVehicles();
            cout << "Enter Vehicle ID : "; cin >> vid;

            cout << "Enter Monthly Fee: Rs. "; cin >> fee;

            tm.applyTransport(s->getId(), rid, vid, fee);
        }
        else if (choice == 5)
        {
            tm.displayStudentPass(s->getId());
        }
        else if (choice == 6)
        {
            int pid;
            cout << "Enter your Pass ID: "; cin >> pid;
            tm.payBill(pid);
        }
        else if (choice == 7)
        {
            char confirm;
            cout << "\nAre you sure? (y/n): "; cin >> confirm;
            if (confirm == 'y' || confirm == 'Y')
            {
                tm.cancelTransport(s->getId());
            }
        }
        else if (choice == 8)
        {
            cout << "\nLogged out successfully.\n";
        }
        else
        {
            cout << "\nInvalid choice!\n";
        }

    } while (choice != 8);
}

// ======================== ADMIN MENU ========================

void adminMenu(Admin* a)
{
    int choice;

    do
    {
        cout << "\n======================================\n";
        cout << "   ADMIN MENU - " << a->getName() << "\n";
        cout << "======================================\n";
        cout << "1.  View All Students\n";
        cout << "2.  View All Vehicles\n";
        cout << "3.  View All Routes\n";
        cout << "4.  View All Applications\n";
        cout << "5.  Add Bus\n";
        cout << "6.  Add Van\n";
        cout << "7.  Remove Vehicle\n";
        cout << "8.  Add Route\n";
        cout << "9.  Assign Vehicle to Route\n";
        cout << "10. Approve Transport Request\n";
        cout << "11. Reject Transport Request\n";
        cout << "12. Apply Late Fine\n";
        cout << "13. Generate Report\n";
        cout << "14. Save Data\n";
        cout << "15. Logout\n";
        cout << "--------------------------------------\n";
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 1)
        {
            tm.displayAllStudents();
        }
        else if (choice == 2)
        {
            tm.displayAllVehicles();
        }
        else if (choice == 3)
        {
            tm.displayAllRoutes();
        }
        else if (choice == 4)
        {
            tm.displayAllPasses();
        }
        else if (choice == 5)
        {
            int id, cap; string model, type;

            cout << "\n--- ADD BUS ---\n";
            cout << "Vehicle ID  : "; cin >> id;

            if (tm.vehicleIdExists(id))
            {
                cout << "\nError: Vehicle ID already exists!\n";
                continue;
            }

            cout << "Model       : "; cin >> model;
            cout << "Capacity    : "; cin >> cap;
            cout << "Type (AC/NonAC/Mini): "; cin >> type;

            tm.addVehicle(new Bus(id, model, cap, type));
        }
        else if (choice == 6)
        {
            int id, cap; string model; bool ac;
            int acInput;

            cout << "\n--- ADD VAN ---\n";
            cout << "Vehicle ID  : "; cin >> id;

            if (tm.vehicleIdExists(id))
            {
                cout << "\nError: Vehicle ID already exists!\n";
                continue;
            }

            cout << "Model       : "; cin >> model;
            cout << "Capacity    : "; cin >> cap;
            cout << "AC (1=Yes, 0=No): "; cin >> acInput;
            ac = (acInput == 1);

            tm.addVehicle(new Van(id, model, cap, ac));
        }
        else if (choice == 7)
        {
            int id;
            cout << "\nEnter Vehicle ID to remove: "; cin >> id;
            tm.removeVehicle(id);
        }
        else if (choice == 8)
        {
            int id; string s, e; double d;

            cout << "\n--- ADD ROUTE ---\n";
            cout << "Route ID    : "; cin >> id;

            if (tm.routeIdExists(id))
            {
                cout << "\nError: Route ID already exists!\n";
                continue;
            }

            cout << "Start Point : "; cin >> s;
            cout << "End Point   : "; cin >> e;
            cout << "Distance(km): "; cin >> d;

            tm.addRoute(new Route(id, s, e, d));
        }
        else if (choice == 9)
        {
            int rid, vid;
            cout << "\n--- ASSIGN VEHICLE TO ROUTE ---\n";
            tm.displayAllRoutes();
            cout << "Enter Route ID  : "; cin >> rid;
            tm.displayAllVehicles();
            cout << "Enter Vehicle ID: "; cin >> vid;
            tm.assignVehicleToRoute(rid, vid);
        }
        else if (choice == 10)
        {
            int pid;
            cout << "\nEnter Pass ID to approve: "; cin >> pid;
            tm.approveRequest(pid);
        }
        else if (choice == 11)
        {
            int pid;
            cout << "\nEnter Pass ID to reject: "; cin >> pid;
            tm.rejectRequest(pid);
        }
        else if (choice == 12)
        {
            int pid; double fine;
            cout << "\n--- APPLY LATE FINE ---\n";
            cout << "Enter Pass ID    : "; cin >> pid;
            cout << "Enter Fine Amount: Rs. "; cin >> fine;
            tm.applyLateFine(pid, fine);
        }
        else if (choice == 13)
        {
            tm.generateReports();
        }
        else if (choice == 14)
        {
            tm.saveData();
        }
        else if (choice == 15)
        {
            cout << "\nLogged out successfully.\n";
        }
        else
        {
            cout << "\nInvalid choice!\n";
        }

    } while (choice != 15);
}
