#include "Route.h"
#include "Vehicle.h"

Route::Route()
{
    routeId = 0;
    startPoint = "";
    endPoint = "";
    distance = "";
    assignedVehicle = nullptr;
}

Route::Route(int id, string s, string e, double d)
{
    routeId = id;
    startPoint = s;
    endPoint = e;
    distance = d;
    assignedVehicle = nullptr;
}

Route::Route(const Route& obj)
{
    routeId = obj.routeId;
    startPoint = obj.startPoint;
    endPoint = obj.endPoint;
    distance = obj.distance;
    assignedVehicle = obj.assignedVehicle;
}

Route& Route::operator=(const Route& obj)
{
    if (this != &obj)
    {
        routeId = obj.routeId;
        startPoint = obj.startPoint;
        endPoint = obj.endPoint;
        distance = obj.distance;
        assignedVehicle = obj.assignedVehicle;
    }
    return *this;
}

int Route::getRouteId() const { return routeId; }
string Route::getStartPoint() const { return startPoint; }
string Route::getEndPoint() const { return endPoint; }
string Route::getDistance()  const{ return distance; }

void Route::setRouteId(int id) { routeId = id; }
void Route::setStartPoint(string s) { startPoint = s; }
void Route::setEndPoint(string e) { endPoint = e; }
void Route::setDistance(string d) { distance = d; }

void Route::assignVehicle(Vehicle* v) { assignedVehicle = v; }

void Route::displayRoute() const
{
    cout << "\n========== ROUTE DETAILS ==========\n";
    cout << "Route ID   : " << routeId << endl;
    cout << "Start      : " << startPoint << endl;
    cout << "End        : " << endPoint << endl;
    cout << "Distance   : " << distance << " km" << endl;
    cout << "Vehicle    : " << (assignedVehicle ? "Assigned" : "Not Assigned") << endl;
}

Route::~Route() {}
