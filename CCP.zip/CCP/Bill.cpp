#include "Bill.h"

Bill::Bill()
{
    billId = 0;
    baseFee = 0;
    lateFine = 0;
    isPaid = false;
}

Bill::Bill(int id, double fee)
{
    billId = id;
    baseFee = fee;
    lateFine = 0;
    isPaid = false;
}

Bill::Bill(const Bill& obj)
{
    billId = obj.billId;
    baseFee = obj.baseFee;
    lateFine = obj.lateFine;
    isPaid = obj.isPaid;
}

Bill& Bill::operator=(const Bill& obj)
{
    if (this != &obj)
    {
        billId = obj.billId;
        baseFee = obj.baseFee;
        lateFine = obj.lateFine;
        isPaid = obj.isPaid;
    }
    return *this;
}

void Bill::setBillId(int id) { billId = id; }
void Bill::setBaseFee(double fee) { baseFee = fee; }
void Bill::setLateFine(double fine) { lateFine = fine; }
void Bill::setPaymentStatus(bool s) { isPaid = s; }

int Bill::getBillId() const { return billId; }
double Bill::getBaseFee() const { return baseFee; }
double Bill::getLateFine() const { return lateFine; }
bool Bill::getPaymentStatus() const { return isPaid; }

void Bill::applyLateFine(double fine) { lateFine += fine; }
double Bill::calculateTotal() const { return baseFee + lateFine; }
void Bill::markAsPaid() { isPaid = true; }

void Bill::displayBill() const
{
    cout << "\n--- BILL ---\n";
    cout << "Bill ID   : " << billId << endl;
    cout << "Base Fee  : Rs. " << baseFee << endl;
    cout << "Late Fine : Rs. " << lateFine << endl;
    cout << "Total     : Rs. " << calculateTotal() << endl;
    cout << "Status    : " << (isPaid ? "PAID" : "UNPAID") << endl;
}

Bill::~Bill() {}
