#include "TransportManager.h"

TransportManager::TransportManager()
{
    students = new Student*[100];
    admins   = new Admin*[10];
    vehicles = new Vehicle*[100];
    routes   = new Route*[100];
    passes   = new TransportPass*[100];

    studentCount = 0;
    adminCount   = 0;
    vehicleCount = 0;
    routeCount   = 0;
    passCount    = 0;

    // Default admin (always present)
    admins[adminCount++] = new Admin(1, "admin", "admin123", "Transport Head");

    loadStudents();
    loadVehicles();
    loadRoutes();
    loadPasses();
}

// ======================== AUTHENTICATION ========================

Student* TransportManager::loginStudent(int id, string password)
{
    for (int i = 0; i < studentCount; i++)
    {
        if (students[i]->getId() == id &&
            students[i]->getPassword() == password)
        {
            return students[i];
        }
    }
    return nullptr;
}

Admin* TransportManager::loginAdmin(int id, string password)
{
    for (int i = 0; i < adminCount; i++)
    {
        if (admins[i]->getId() == id &&
            admins[i]->getPassword() == password)
        {
            return admins[i];
        }
    }
    return nullptr;
}

// ======================== STUDENT ========================

bool TransportManager::studentIdExists(int id)
{
    for (int i = 0; i < studentCount; i++)
        if (students[i]->getId() == id) return true;
    return false;
}

void TransportManager::addStudent(Student* s)
{
    students[studentCount++] = s;
    cout << "\nStudent registered successfully!\n";
}

// ======================== ADMIN ========================

void TransportManager::addAdmin(Admin* a)
{
    admins[adminCount++] = a;
}

// ======================== VEHICLE ========================

bool TransportManager::vehicleIdExists(int id)
{
    for (int i = 0; i < vehicleCount; i++)
        if (vehicles[i]->getVehicleId() == id) return true;
    return false;
}

void TransportManager::addVehicle(Vehicle* v)
{
    vehicles[vehicleCount++] = v;
    cout << "\nVehicle added successfully!\n";
}

void TransportManager::removeVehicle(int id)
{
    for (int i = 0; i < vehicleCount; i++)
    {
        if (vehicles[i]->getVehicleId() == id)
        {
            delete vehicles[i];
            for (int j = i; j < vehicleCount - 1; j++)
                vehicles[j] = vehicles[j + 1];
            vehicleCount--;
            cout << "\nVehicle removed successfully!\n";
            return;
        }
    }
    cout << "\nVehicle ID not found!\n";
}

// ======================== ROUTE ========================

bool TransportManager::routeIdExists(int id)
{
    for (int i = 0; i < routeCount; i++)
        if (routes[i]->getRouteId() == id) return true;
    return false;
}

void TransportManager::addRoute(Route* r)
{
    routes[routeCount++] = r;
    cout << "\nRoute added successfully!\n";
}

// ======================== ASSIGN ========================

void TransportManager::assignVehicleToRoute(int rid, int vid)
{
    Route*   r = nullptr;
    Vehicle* v = nullptr;

    for (int i = 0; i < routeCount; i++)
        if (routes[i]->getRouteId() == rid) r = routes[i];

    for (int i = 0; i < vehicleCount; i++)
        if (vehicles[i]->getVehicleId() == vid) v = vehicles[i];

    if (!r) { cout << "\nRoute not found!\n"; return; }
    if (!v) { cout << "\nVehicle not found!\n"; return; }

    r->assignVehicle(v);
    v->assignRoute(r);
    cout << "\nVehicle assigned to route successfully!\n";
}

// ======================== TRANSPORT APPLICATION ========================

void TransportManager::applyTransport(int sid, int rid, int vid, double fee)
{
    Student* s = nullptr;
    Route*   r = nullptr;
    Vehicle* v = nullptr;

    for (int i = 0; i < studentCount; i++)
        if (students[i]->getId() == sid) s = students[i];

    for (int i = 0; i < routeCount; i++)
        if (routes[i]->getRouteId() == rid) r = routes[i];

    for (int i = 0; i < vehicleCount; i++)
        if (vehicles[i]->getVehicleId() == vid) v = vehicles[i];

    if (!s) { cout << "\nStudent not found!\n"; return; }
    if (!r) { cout << "\nRoute not found!\n"; return; }
    if (!v) { cout << "\nVehicle not found!\n"; return; }

    // Check if student already applied
    for (int i = 0; i < passCount; i++)
    {
        if (passes[i]->getStudentId() == sid)
        {
            cout << "\nYou already have a transport application!\n";
            return;
        }
    }

    if (!v->hasSpace())
    {
        cout << "\nVehicle is full! No seats available.\n";
        return;
    }

    v->occupySeat();
    passes[passCount] = new TransportPass(passCount + 1, sid, vid, rid, fee);
    passCount++;

    cout << "\nTransport application submitted! Pass ID: " << passCount << endl;
}

void TransportManager::cancelTransport(int sid)
{
    for (int i = 0; i < passCount; i++)
    {
        if (passes[i]->getStudentId() == sid)
        {
            // Free the seat
            int vid = passes[i]->getVehicleId();
            for (int j = 0; j < vehicleCount; j++)
            {
                if (vehicles[j]->getVehicleId() == vid)
                {
                    vehicles[j]->freeSeat();
                    break;
                }
            }

            delete passes[i];
            for (int j = i; j < passCount - 1; j++)
                passes[j] = passes[j + 1];
            passCount--;

            cout << "\nTransport registration cancelled successfully!\n";
            return;
        }
    }
    cout << "\nNo transport application found for this student.\n";
}

// ======================== PASS MANAGEMENT ========================

void TransportManager::approveRequest(int pid)
{
    for (int i = 0; i < passCount; i++)
    {
        if (passes[i]->getPassId() == pid)
        {
            passes[i]->approve();
            return;
        }
    }
    cout << "\nPass ID not found!\n";
}

void TransportManager::rejectRequest(int pid)
{
    for (int i = 0; i < passCount; i++)
    {
        if (passes[i]->getPassId() == pid)
        {
            passes[i]->reject();
            return;
        }
    }
    cout << "\nPass ID not found!\n";
}

void TransportManager::payBill(int pid)
{
    for (int i = 0; i < passCount; i++)
    {
        if (passes[i]->getPassId() == pid)
        {
            if (passes[i]->isBillPaid())
                cout << "\nBill is already paid!\n";
            else
                passes[i]->payBill();
            return;
        }
    }
    cout << "\nPass ID not found!\n";
}

void TransportManager::applyLateFine(int pid, double fine)
{
    for (int i = 0; i < passCount; i++)
    {
        if (passes[i]->getPassId() == pid)
        {
            passes[i]->applyLateFine(fine);
            cout << "\nLate fine of Rs. " << fine << " applied!\n";
            return;
        }
    }
    cout << "\nPass ID not found!\n";
}

// ======================== DISPLAY ========================

void TransportManager::displayAllStudents()
{
    if (studentCount == 0)
    {
        cout << "\nNo students registered.\n";
        return;
    }
    for (int i = 0; i < studentCount; i++)
        students[i]->display();
}

void TransportManager::displayAllVehicles()
{
    if (vehicleCount == 0)
    {
        cout << "\nNo vehicles available.\n";
        return;
    }
    for (int i = 0; i < vehicleCount; i++)
        vehicles[i]->displayVehicle();
}

void TransportManager::displayAllRoutes()
{
    if (routeCount == 0)
    {
        cout << "\nNo routes available.\n";
        return;
    }
    for (int i = 0; i < routeCount; i++)
        routes[i]->displayRoute();
}

void TransportManager::displayAllPasses()
{
    if (passCount == 0)
    {
        cout << "\nNo transport applications found.\n";
        return;
    }
    for (int i = 0; i < passCount; i++)
        passes[i]->displayPass();
}

void TransportManager::displayStudentPass(int sid)
{
    bool found = false;
    for (int i = 0; i < passCount; i++)
    {
        if (passes[i]->getStudentId() == sid)
        {
            passes[i]->displayPass();
            found = true;
        }
    }
    if (!found)
        cout << "\nNo transport application found for your account.\n";
}

void TransportManager::generateReports()
{
    cout << "\n========== SYSTEM REPORT ==========\n";
    cout << "Total Students    : " << studentCount << endl;
    cout << "Total Vehicles    : " << vehicleCount << endl;
    cout << "Total Routes      : " << routeCount << endl;
    cout << "Total Applications: " << passCount << endl;

    int approved = 0, pending = 0;
    for (int i = 0; i < passCount; i++)
    {
        if (passes[i]->isApproved()) approved++;
        else pending++;
    }
    cout << "Approved Passes   : " << approved << endl;
    cout << "Pending Passes    : " << pending << endl;
    cout << "===================================\n";
}

// ======================== FILE I/O ========================

void TransportManager::saveStudents()
{
    ofstream fout("students.txt");
    for (int i = 0; i < studentCount; i++)
    {
        fout << students[i]->getId()             << " "
             << students[i]->getName()           << " "
             << students[i]->getPassword()       << " "
             << students[i]->getDepartment()     << " "
             << students[i]->getTransportStatus()<< "\n";
    }
    fout.close();
}

void TransportManager::loadStudents()
{
    ifstream fin("students.txt");
    if (!fin) return;

    int id; string name, pass, dept; bool status;
    while (fin >> id >> name >> pass >> dept >> status)
    {
        students[studentCount++] = new Student(id, name, pass, dept, status);
    }
    fin.close();
}

void TransportManager::saveVehicles()
{
    ofstream fout("vehicles.txt");
    for (int i = 0; i < vehicleCount; i++)
    {
        Bus* b = dynamic_cast<Bus*>(vehicles[i]);
        if (b)
            fout << "BUS " << b->getVehicleId() << " "
                 << b->getModel() << " "
                 << b->getCapacity() << " "
                 << b->getBusType() << "\n";

        Van* v = dynamic_cast<Van*>(vehicles[i]);
        if (v)
            fout << "VAN " << v->getVehicleId() << " "
                 << v->getModel() << " "
                 << v->getCapacity() << " "
                 << v->getAC() << "\n";
    }
    fout.close();
}

void TransportManager::loadVehicles()
{
    ifstream fin("vehicles.txt");
    if (!fin) return;

    string type;
    while (fin >> type)
    {
        if (type == "BUS")
        {
            int id, cap; string model, busType;
            fin >> id >> model >> cap >> busType;
            vehicles[vehicleCount++] = new Bus(id, model, cap, busType);
        }
        else if (type == "VAN")
        {
            int id, cap; string model; bool ac;
            fin >> id >> model >> cap >> ac;
            vehicles[vehicleCount++] = new Van(id, model, cap, ac);
        }
    }
    fin.close();
}

void TransportManager::saveRoutes()
{
    ofstream fout("routes.txt");
    for (int i = 0; i < routeCount; i++)
    {
        fout << routes[i]->getRouteId()    << " "
             << routes[i]->getStartPoint() << " "
             << routes[i]->getEndPoint()   << " "
             << routes[i]->getDistance()   << "\n";
    }
    fout.close();
}

void TransportManager::loadRoutes()
{
    ifstream fin("routes.txt");
    if (!fin) return;

    int id; string s, e; double d;
    while (fin >> id >> s >> e >> d)
    {
        routes[routeCount++] = new Route(id, s, e, d);
    }
    fin.close();
}

void TransportManager::savePasses()
{
    ofstream fout("passes.txt");
    for (int i = 0; i < passCount; i++)
    {
        fout << passes[i]->getPassId()    << " "
             << passes[i]->getStudentId() << " "
             << passes[i]->getVehicleId() << " "
             << passes[i]->getRouteId()   << " "
             << passes[i]->isApproved()   << " "
             << passes[i]->isBillPaid()   << "\n";
    }
    fout.close();
}

void TransportManager::loadPasses()
{
    ifstream fin("passes.txt");
    if (!fin) return;

    int pid, sid, vid, rid; bool approved, paid;
    while (fin >> pid >> sid >> vid >> rid >> approved >> paid)
    {
        TransportPass* p = new TransportPass(pid, sid, vid, rid, 0);
        p->setApproval(approved);
        if (paid) p->payBill();
        passes[passCount++] = p;
    }
    fin.close();
}

void TransportManager::saveData()
{
    saveStudents();
    saveVehicles();
    saveRoutes();
    savePasses();
    cout << "\nAll data saved successfully!\n";
}

// ======================== DESTRUCTOR ========================

TransportManager::~TransportManager()
{
    for (int i = 0; i < studentCount; i++) delete students[i];
    for (int i = 0; i < adminCount; i++)   delete admins[i];
    for (int i = 0; i < vehicleCount; i++) delete vehicles[i];
    for (int i = 0; i < routeCount; i++)   delete routes[i];
    for (int i = 0; i < passCount; i++)    delete passes[i];

    delete[] students;
    delete[] admins;
    delete[] vehicles;
    delete[] routes;
    delete[] passes;
}
