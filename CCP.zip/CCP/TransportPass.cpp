#include "TransportPass.h"

TransportPass::TransportPass()
{
    passId = 0;
    studentId = 0;
    vehicleId = 0;
    routeId = 0;
    approved = false;
}

TransportPass::TransportPass(int pid, int sid, int vid, int rid, double fee)
{
    passId = pid;
    studentId = sid;
    vehicleId = vid;
    routeId = rid;
    approved = false;
    bill = Bill(pid, fee);
}

TransportPass::TransportPass(const TransportPass& obj) : bill(obj.bill)
{
    passId = obj.passId;
    studentId = obj.studentId;
    vehicleId = obj.vehicleId;
    routeId = obj.routeId;
    approved = obj.approved;
}

TransportPass& TransportPass::operator=(const TransportPass& obj)
{
    if (this != &obj)
    {
        passId = obj.passId;
        studentId = obj.studentId;
        vehicleId = obj.vehicleId;
        routeId = obj.routeId;
        approved = obj.approved;
        bill = obj.bill;
    }
    return *this;
}

int TransportPass::getPassId() const { return passId; }
int TransportPass::getStudentId() const { return studentId; }
int TransportPass::getVehicleId() const { return vehicleId; }
int TransportPass::getRouteId() const { return routeId; }
bool TransportPass::isApproved() const { return approved; }

void TransportPass::setApproval(bool s) { approved = s; }

void TransportPass::approve()
{
    approved = true;
    cout << "\nTransport Pass Approved!\n";
}

void TransportPass::reject()
{
    approved = false;
    cout << "\nTransport Pass Rejected.\n";
}

void TransportPass::generateBill(double fee)
{
    bill.setBaseFee(fee);
}

void TransportPass::applyLateFine(double fine)
{
    bill.applyLateFine(fine);
}

void TransportPass::payBill()
{
    bill.markAsPaid();
    cout << "\nBill paid successfully!\n";
}

bool TransportPass::isBillPaid() const
{
    return bill.getPaymentStatus();
}

void TransportPass::displayPass() const
{
    cout << "\n========== TRANSPORT PASS ==========\n";
    cout << "Pass ID    : " << passId << endl;
    cout << "Student ID : " << studentId << endl;
    cout << "Vehicle ID : " << vehicleId << endl;
    cout << "Route ID   : " << routeId << endl;
    cout << "Status     : " << (approved ? "Approved" : "Pending") << endl;
    bill.displayBill();
}

TransportPass::~TransportPass() {}
