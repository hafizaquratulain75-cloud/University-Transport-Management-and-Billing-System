#include "Bus.h"

Bus::Bus() : Vehicle() { busType = ""; }

Bus::Bus(int id, string model, int cap, string type)
    : Vehicle(id, model, cap) { busType = type; }

Bus::Bus(const Bus& obj) : Vehicle(obj) { busType = obj.busType; }

Bus& Bus::operator=(const Bus& obj)
{
    if (this != &obj)
    {
        Vehicle::operator=(obj);
        busType = obj.busType;
    }
    return *this;
}

void Bus::setBusType(string t) { busType = t; }
string Bus::getBusType() const { return busType; }

void Bus::displayVehicle()
{
    cout << "\n========== BUS DETAILS ==========\n";
    cout << "Vehicle ID     : " << vehicleId << endl;
    cout << "Model          : " << model << endl;
    cout << "Type           : " << busType << endl;
    cout << "Capacity       : " << capacity << endl;
    cout << "Occupied Seats : " << occupiedSeats << endl;
    cout << "Available Seats: " << (capacity - occupiedSeats) << endl;
}

Bus::~Bus() {}
